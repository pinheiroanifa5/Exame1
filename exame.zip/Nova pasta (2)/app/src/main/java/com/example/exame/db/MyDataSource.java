package com.example.exame.db;



import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.exame.model.Product;


import java.util.ArrayList;
import java.util.List;

public class MyDataSource {
    private SQLiteDatabase database;
    private DbHelper dbHelper;

    public MyDataSource(Context context) {
        dbHelper = new DbHelper(context);
    }

    public void open() {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public void insertData(String name,  String status) {

        ContentValues values = new ContentValues();
        values.put(DbHelper.COLUMN_NAME, name);;
        values.put(DbHelper.COLUMN_STATUS, status);
        Log.d("MyDataSource", "Before Insert: " + name + ", " + status);

        long result = database.insert(DbHelper.TABLE_NAME, null, values);

        Log.d("MyDataSource", "After Insert - Result: " + result);


    }

    public List<Product> getAllData() {
        List<Product> dataList = new ArrayList<>();

        Cursor cursor = database.query(
                DbHelper.TABLE_NAME,

                null,
                null,
                null,
                null,
                null,
                "name ASC"
        );

        if (cursor != null && cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(cursor.getColumnIndexOrThrow(DbHelper.COLUMN_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(DbHelper.COLUMN_NAME));
                String status = cursor.getString(cursor.getColumnIndexOrThrow(DbHelper.COLUMN_STATUS));
                Product product = new Product(id, name, status);
                dataList.add(product);
            } while (cursor.moveToNext());

            cursor.close();
        }

        return dataList;
    }





    public void updateData(long id, String newName, Double newNota1, Double newNota2, Double newMedia, String newStatus) {
        ContentValues values = new ContentValues();
        values.put(DbHelper.COLUMN_NAME, newName);
        values.put(DbHelper.COLUMN_STATUS, newStatus);
        String whereClause = DbHelper.COLUMN_ID + "=?";
        String[] whereArgs = {String.valueOf(id)};
        database.update(DbHelper.TABLE_NAME, values, whereClause, whereArgs);
    }

    public void deleteData(long id) {
        String whereClause = DbHelper.COLUMN_ID + "=?";
        String[] whereArgs = {String.valueOf(id)};
        database.delete(DbHelper.TABLE_NAME, whereClause, whereArgs);
    }
}

